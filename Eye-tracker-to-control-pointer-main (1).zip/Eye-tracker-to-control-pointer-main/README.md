libraries need to installed using pip :
OpenCV
Media pipe
PYAutoGUI
after that use any idle to run the code 

code results:
output screen1:
![image](https://github.com/user-attachments/assets/8d9d9396-8007-47b4-a335-20e52b5161f1)

ouput screen2:
![image](https://github.com/user-attachments/assets/3a42a0bf-8f05-48fe-bdab-46caad3aaa18)





